
import { Component } from '@angular/core';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css'],
})
export class AboutComponent {
  heading: string = 'About Our Company';
  description: string = `
    Welcome to our company photogallery company ! We are dedicated to providing high-quality products 
    that enhance images to our customers. Our online store specializes in a 
    variety of img items, including . Thank you for choosing us as your trusted 
    online retailer!`;
}
