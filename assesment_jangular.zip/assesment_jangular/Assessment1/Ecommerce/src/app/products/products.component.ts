
import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import Swal from 'sweetalert2';

interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
}

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css'],
})
export class ProductsComponent implements OnInit {
  products: Product[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.getProducts();
  }

  getProducts(): void {
    const apiUrl = 'http://127.0.0.1:8000/products/';
    
    this.http.get<Product[]>(apiUrl).subscribe(
      (data) => {
        console.log(data);
        this.products = data;
      },
      (error) => {
        console.error('There was an error fetching the products!', error);
      }
    );
  }

  addToCart(product: Product) {
    let cart = JSON.parse(localStorage.getItem('cart') || '[]');
    cart.push(product);
    localStorage.setItem('cart', JSON.stringify(cart));

    Swal.fire({
      title: 'Added Successfully!',
      text: `Added ${product.name} to cart`,
      icon: 'success',
    });
  }

  getimagepath(path:string){
    return 'http://127.0.0.1:8000'+path
  }
}

