
import React, { useState } from 'react';
import axios from 'axios';
import Checkbox from '@mui/material/Checkbox';
import { useNavigate, Link } from 'react-router-dom';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';
import { TextField } from '@mui/material';


const Register = () => {
    const [formData, setFormData] = useState({
        userName: '',
        password: '',
        fname: '',
        lname: '',
        Married_Status: false,
        gender: '',
        DOB:'', 
        photo : null,
    });
    console.log(formData)

    const [error, setError] = useState(null);
    const navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: type === 'checkbox' ? checked : value,
        }));
    };

    const handleFileChange = (e) => {
        const file = e.target.files[0]
        console.log(file , "fdkgvnsdjkl");
        
          setFormData((prevData) => ({
              ...prevData,
              photo : file
          }));
      };

    const handleSubmit = async (e) => {
        e.preventDefault();
        console.log(formData)
        try {
            const response = await axios.post('http://localhost:5000/api/register', formData,{
                headers:{
                    "Content-Type":"multipart/form-data"
                }
            });
            console.log('Register successful:', response.data);
            navigate('/login');
        } catch (err) {
            setError('Register failed. Please try again.');
            console.error(err);
        }
    

        //upload imag ecode

        const data = new FormData();
        Object.keys(formData).forEach(key => {
          if (key === 'photo') {
            data.append(key, formData[key]);
          } else {
            data.append(key, formData[key]); 
          }
        });
         console.log(data , "data")
        console.log("formdatadata);", data)
        try {
            const response = await axios.post('http://localhost:5000/api/register', data);
            navigate('/');
            console.log('SignUp successful:');
        } catch (err) {
            console.log(err.message)
            setError('Login failed. Please check your credentials.');
        }
    };


  


    return (
        <div>
            <h2>Register</h2>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            <form   onSubmit={handleSubmit}>
                <div>
                    <label>First Name:</label>
                    <input
                       type="text"
                        name="fname"
                        value={formData.fname}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div>
                    <label>Last Name:</label>
                    <input
                        type="text"
                        name="lname"
                        value={formData.lname}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div>
                    <label>Email:</label>
                    <input
                        type="email"
                        name="userName"
                        value={formData.userName}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div>
                    <label>Password:</label>
                    <input
                        type="password"
                        name="password"
                        value={formData.password}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div>
                    <label>Married Status</label>
                    <Checkbox
                        name="Married_Status"
                        checked={formData.Married_Status}
                        onChange={handleChange}
                        inputProps={{ 'aria-label': 'controlled' }}
                    />
                </div>
                <div>
                    <label>DOB:</label>
                    <input
                        type="date"
                        name="DOB"
                        value={formData.DOB}
                        onChange={handleChange}
                        required
                    />
                </div>
                <TextField
                    id="photo"
                    name="photo"
                    type="file"
                    // value={formData.photo}
                    onChange={handleFileChange}
                    defaultValue=""
                    fullWidth
                    sx={{ mb: 3 }}
                    
                />
            


                <FormControl>
                    <FormLabel id="gender-label">Gender</FormLabel>
                    <RadioGroup
                        row
                        aria-labelledby="gender-label"
                        name="gender"
                        value={formData.gender}
                        onChange={handleChange}
                    >
                        <FormControlLabel value="female" control={<Radio />} label="Female" />
                        <FormControlLabel value="male" control={<Radio />} label="Male" />
                        <FormControlLabel value="other" control={<Radio />} label="Other" />
                    </RadioGroup>
                </FormControl>

                <button type="submit">Register</button>
                <div className="text-center">
                    Have an account? <Link to="/">Login</Link>
                </div>
            </form>
        </div>
    );
};

export default Register;