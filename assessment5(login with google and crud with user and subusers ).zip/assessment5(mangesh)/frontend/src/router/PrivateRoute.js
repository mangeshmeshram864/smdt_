import {React} from "react";
import PrivateLayout from "../layout/PrivateLayout";
import NotFound from "../component/NotFound";
import UserManagement from "../component/UserManagement";
import PublicLayout from "../layout/PublicLayout";
import UserProfile from "../component/UserProfile";
import SubUserDetails from "../component/subUserDetails";
import AddSubUser from "../component/addSubUser";


const privateRoutes = [
	{
		path: "/users",
		exact: true,
		element: <PrivateLayout><UserManagement/></PrivateLayout>
	},
	{ path: "/*", element: <NotFound/> },
	
	{ path:"/Subusers",
		exact:true,
	},
	{
    	path: "/userProfile",
    	exact: true,
    	element: <PublicLayout><UserProfile/></PublicLayout>
    },
	{
		path: "/details/:id",
		exact: true,
		element: <PrivateLayout><SubUserDetails/></PrivateLayout>
	},
	{
		path: "/addSubUser",
		exact: true,
		element: <PrivateLayout><AddSubUser/></PrivateLayout>
	},

];
export default privateRoutes;
