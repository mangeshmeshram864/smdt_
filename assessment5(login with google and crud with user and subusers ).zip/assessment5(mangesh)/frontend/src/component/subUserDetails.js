
import * as React from 'react';
import axios from 'axios';
import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';


    



export default function SubUserDetails() {

    const [data, setData] = useState([])

    console.log('data-----', typeof data)

    const params = useParams()

    const fetchDataById = async (id) => {
        try {
            const response = await axios.get(`http://localhost:5000/api/getsub_user/${id}`)
            console.log(response.data)
            setData(response.data)
        } catch (error) {
            setData([])
        }
    }

    useEffect(() => {
        fetchDataById(params.id)
    }, [params.id])

    return (

        <>
            <h1>First Name : {data.firstName}</h1>
            <h1>Last Name : {data.lastName}</h1>
            <h1>Email Name : {data.email}</h1>
        </>
    );
}

