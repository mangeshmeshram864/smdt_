import axios from "axios";
import { useState, useEffect } from "react";
import {
    TextField,
    Button,
    Checkbox,
    RadioGroup,
    FormControlLabel,
    FormControl,
} from "@mui/material";
import Swal from 'sweetalert2';
import 'sweetalert2/dist/sweetalert2.min.css';
import { useNavigate } from "react-router-dom";
import Radio from '@mui/material/Radio';
// import '../component/userProfile.css'



let token = localStorage.getItem('token');
const UserProfile = () => {
    const navigate = useNavigate();
    const user = localStorage.getItem('userId');
    const [data, setData] = useState({
        fname: '',
        lname: '',
        userName: '',
        Married_Status: false,
        photo:'',
        gender: ''
    });

    const fetchUserById = async (userId) => {
        try {
            const response = await axios.get(`http://localhost:5000/api/get_user/${userId}`,
                {
                    headers: {
                        Authorization: `${token}`,
                        'Content-Type': 'application/json'
                    }
                }
            );
            setData(response.data);
            console.log(response.data)
        } catch (error) {
            console.error('Error fetching user data', error);
            setData({
                fname: '',
                lname: '',
                userName: '',
                Married_Status: false,
                photo:'',
                gender: ''
            });
        }
    };

    useEffect(() => {
        if (user) {
            fetchUserById(user);
        }
    }, [user]);

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setData((prevData) => ({
            ...prevData,
            [name]: type === 'checkbox' ? checked : value,
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.put(`http://localhost:5000/api/updateUser/${user}`, data, {
                headers: {
                    Authorization: `${token}`,
                    'Content-Type': 'application/json'
                }
            });
            Swal.fire('Success', 'User Updated Successfully', 'success');
            navigate('/users');
        } catch (error) {
            console.error('Error updating user data', error);
            Swal.fire('Error', 'Could not update user data', 'error');
        }
    };

    return (
        <form onSubmit={handleSubmit} className="form-container">
            <h1>User Profile</h1>

            <div className="profile">
                <p>Profile Picture</p>
                <img
                    src={data.photo}
                    alt="Profile"
                    height={100}
                    width={100}
                />
            </div>

            <label>First Name</label>
            <TextField
                id="fname"
                name="fname"
                value={data.fname}
                onChange={handleChange}
                fullWidth
                sx={{ mb: 3 }}
            />

            <label>Last Name</label>
            <TextField
                id="lname"
                name="lname"
                value={data.lname}
                onChange={handleChange}
                fullWidth
                sx={{ mb: 3 }}
            />

            <label>Username</label>
            <TextField
                id="userName"
                name="userName"
                value={data.userName}
                onChange={handleChange}
                fullWidth
                sx={{ mb: 3 }}
            />

            <FormControlLabel
                control={<Checkbox name="Married_Status" checked={data.Married_Status} onChange={handleChange} />}
                label="Married"
            />

            <FormControl>
                <RadioGroup
                    aria-labelledby="gender-label"
                    name="gender"
                    value={data.gender}
                    onChange={handleChange}
                >
                    <FormControlLabel value="female" control={<Radio />} label="Female" />
                    <FormControlLabel value="male" control={<Radio />} label="Male" />
                    <FormControlLabel value="other" control={<Radio />} label="Other" />
                </RadioGroup>
            </FormControl>

            <Button variant="contained" color="primary" type="submit">
                Update
            </Button>
        </form>
    );
};

export default UserProfile;
