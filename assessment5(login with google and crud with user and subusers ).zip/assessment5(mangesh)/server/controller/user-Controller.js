const jwt = require('jsonwebtoken')
const bcrypt = require('bcryptjs');
const User = require('../model/user-Model');


import { OAuth2Client } from 'google-auth-library';

const client = new OAuth2Client('400425828105-3ml5b9n37ll8ddlghmjcc2e83345edn7.apps.googleusercontent.com')



const registerUser = async (req, res) => {
    
    try {
        const { userName, password,lname,fname,gender,Married_Status} = req.body;
        const profile = req.file?.filename
        console.log(profile,"gggggggggg")
        let hashed = await bcrypt.hash(password, 10)

        const user = new User({
            userName: userName,
            password: hashed,
            lname:lname,
            fname:fname,
            gender:gender,
            Married_Status:Married_Status,
            photo : profile,

        })
        //   console.log(user);
        const data = await user.save()
        res.status(200).json(data)
    } catch (error) {
        console.log(error);
        res.status(401).json({ Error: error.message });
    }
}

export const loginWithGoogle = async (req, res) => {
    const { token } = req.body;
    console.log(token , req.body , "JKGHJFGVHJVGJFGHJVGHJ")

    try {
        // Verify the ID token
        const ticket = await client.verifyIdToken({
            idToken: token,  // Token from frontend
            audience: '400425828105-3ml5b9n37ll8ddlghmjcc2e83345edn7.apps.googleusercontent.com',  // Should match CLIENT_ID
        });
        
        const payload = ticket.getPayload();  


        console.log(payload,"payload.....")

        // Extract user details from the token payload
        const googleId = payload.sub; // Google user ID
        const email_id = payload.email; // User email from Google

        // Check if email_id is defined
        if (!email_id) {
            throw new Error('Email ID is missing from the token payload');
        }

        const username = email_id.split('@')[0]; // Assign default username

        console.log(username,"username>>>>>>>>>>>")
        // Check if the user exists in the database
        let user = await User.findOne({ email_id });
        console.log(user,"user>>>>>>>>>>>>>>>>>>>>>")
        if (!user) {
            user = new User({
                userName : payload.email,
                googleId,
                fname : payload.given_name,
                lname : payload.family_name,
                username,
                role: 'user',
                password: googleId,
                photo:payload.picture,
                tokens: [],
            });
            console.log('user----', user)
            await user.save();
        }

        // Generate a JWT token
        const jwtToken = jwt.sign({ userName:email_id , userId: user._id}, "an123idjk", { "expiresIn": "2h" })

    

        // Store the token in the user object
        user.tokens = [{ token: jwtToken }];
        await user.save();
        return res.status(201).json({ message: "Logged In", "token": jwtToken , 'userId' : user._id})

      
    } catch (error) {
        console.log(error.message)
        console.error('Error during Google login:', error.message);
        res.status(401).json({ message: 'Unauthorized', error: error.message });
    }
};






const loginUserDetails = async (req, res) => {
    try {
        const {id}  = req.params
        const user = await User.findById(id)

        console.log(user,"userrrrrrrrrrrrrrrr")
        res.status(200).json(user)
    } catch (error) {
        res.status(500).json({ message: error.message })
    }
}


const updateUserById = async (req, res) => {
    try {
        const user = await User.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        res.json(user);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const loginUser = async (req, res) => {

    try {
        const { userName, password } = req.body;

        const user = await User.findOne({ userName })

        if (!user) {
            return res.status(400).json({ message: "User not found" })
        }

        const isMatch = await bcrypt.compare(password, user.password)

        if (isMatch) {
            const token = jwt.sign({ userName, password, userId: user._id }, "an123idjk", { "expiresIn": "2h" })

            return res.status(201).json({ message: "Logged In", "token": token , 'userId' : user._id})
        } else {
            return res.status(401).json({ message: "Invalid Credentials" })

        }
    } catch (error) {
        res.status(401).json({ Error: error.message })
    }

}





module.exports = {loginUserDetails, loginWithGoogle ,registerUser, loginUser, updateUserById }