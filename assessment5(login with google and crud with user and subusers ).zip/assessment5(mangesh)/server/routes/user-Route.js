const express = require('express');
const router = express.Router();
const userController = require('../controller/user-Controller')
const subUserController = require('../controller/subUser-Controller');
const { verifToken } = require('../middleware/verifyToken');

import {uploadMiddleware} from '../middleware/multer'

router.post('/login', userController.loginUser)

router.post('/register', uploadMiddleware.single('photo'), userController.registerUser);

router.post('/add_user',verifToken, subUserController.addUser)

router.get('/getsub_user', verifToken, subUserController.getAllUser)

router.get('/getsub_user/:id', subUserController.getSubUserById)

router.put('/:id',subUserController.updateSubUser)

router.get('/get_user/:id',userController.loginUserDetails)

router.put('/updateUser/:id',userController.updateUserById)

router.post('/loginwithgoogle', userController.loginWithGoogle)




module.exports = router;

