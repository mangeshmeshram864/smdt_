const jwt = require('jsonwebtoken')
const bcrypt = require('bcryptjs');
const User = require('../model/user-Model');

const registerUser = async (req, res) => {
    try {
        const { userName, password } = req.body;
        let hashed = await bcrypt.hash(password, 10)

        const user = new User({
            userName: userName,
            password: hashed,
            lname:lname,
            fname:fname,
        })

        await user.save()
        res.status(200).json(user)
    } catch (error) {
        console.log(error);
        res.status(401).json({ Error: error.message });
    }
}

const loginUser = async (req, res) => {

    try {
        const { userName, password } = req.body;

        const user = await User.findOne({ userName })

        if (!user) {
            return res.status(400).json({ message: "User not found" })
        }

        const isMatch = await bcrypt.compare(password, user.password)

        if (isMatch) {
            const token = jwt.sign({ userName, password }, "an123idjk", { "expiresIn": "2h" })

            return res.status(201).json({ message: "Logged In", "token": token })
        } else {
            return res.status(401).json({ message: "Invalid Credentials" })

        }
    } catch (error) {
        res.status(401).json({ Error: error.message })
    }

}

module.exports = { registerUser, loginUser }