const mongoose = require('mongoose');

// Define Item Schema
const userSchema = new mongoose.Schema({
      userName: { type: String, required: true },
      password: { type: String, required: true },
      fname:{type:String,required:true},
      lname:{type:String,required:true}
});
// Create Item Model
const User = mongoose.model('User', userSchema);

module.exports = User;