import { React } from "react";
import Form from "../material/form/Form";
import PublicLayout from "../layout/PublicLayout";
import Register  from "../../src/material/form/Register";


const publicRoutes = [
    {
        path: "/",
        exact: true,
        // element: <PublicLayout><SignIn /></PublicLayout>
        element: <PublicLayout><Form /></PublicLayout>
    },
    {
    	path: "/register",
    	exact: true,
    	element: <PublicLayout><Register/></PublicLayout>
    }
];
export default publicRoutes;
