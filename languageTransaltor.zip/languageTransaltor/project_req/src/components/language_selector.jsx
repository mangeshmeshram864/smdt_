
import React from 'react'
import { useTranslation } from 'react-i18next'

const language=[

   {code:'en',lang:'English'},
   {code:'fr',lang:'French'},
   {code:'hi',lang:'Hindi'},


];



const LanguageSelector = () => {

  const {t,i18n}=useTranslation();

const changeLanguage=(lng)=>{ 

   i18n.changeLanguage(lng);
}

  return(
      //  <div className='btn-container'>
      //     {language.map((lng)=>(
      //        <button className={lng.code ===i18n.language ? "selected":" "}  key={lng.code} onClick={()=>changeLanguage(lng.lang)}>
      //          {lng.lang}
      //        </button>
      //     ))}
        
      //    </div>


<div style={{padding: '50px'}}>
     

      {language.map((lng, i) => {
        const { code, lang } = lng;
        return <button onClick={() => changeLanguage(code)}>{lang}</button>;
      })}

    </div>



  )
}

export default LanguageSelector
