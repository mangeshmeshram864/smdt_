 import Subusers from '../model/subUser-model';
import '../model/user-Model'



export const addUser = async (req, res) => {
    try {
        const { firstName, lastName, email} = req.body;
        const userId = req.user.userId

        console.log('userId',userId)
        const user = new Subusers({
            firstName : firstName,
            lastName : lastName,
            email : email,
            userId : userId
        })

        console.log(user);
        await user.save()
        res.status(200).json(user)
       
    } catch (error) {
        console.log(error);
        res.status(401).json({ Error: error.message });
    }
}

export const updateSubUser= async(req,res) =>{
    try{
        const user= await  Subusers.findByIdAndUpdate(req.params.id, req.body,{new:true});
        
        
        if(!user)
        {
            return res.status(404).json({error:'Sub User not found'});
        }
        res.json(user);

    }
    catch(error)
    {
        res.status(400).json({error:'error.message'});
    }
}


 const getSubUserById = async (req, res) => {
    try {
        const { id } = req.params
        const subUser = await Subusers.findById(id)
        res.status(200).json(subUser)
    } catch (error) {
        res.status(500).json({ message: error.message })
    }
}


const getAllUser = async (req, res) => {
    try {
        const { searchText } = req.query;
        const userId = req.user.userId
        console.log('userId---------', userId)

        let filter = {};

        filter.userId = userId;

        if (searchText) {
            filter = {
                ...filter,
                $or: [
                    { firstName: { $regex: searchText, $options: 'i' } },
                    { lastName: { $regex: searchText, $options: 'i' } },
                ]
            };
        }

        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 4;
        const skip = (page - 1) * limit;

        const subUser = await Subusers.find(filter)
            .select('firstName lastName email password maritalStatus dob gender userId')
            .skip(skip)
            .limit(limit);
        const totalCount = await Subusers.countDocuments(filter);

        const response = {
            subUser: subUser,
            pagination: {
                total_record: totalCount,
                per_page: limit,
                current_page: page,
                total_pages: Math.ceil(totalCount / limit),
            },
        };

        res.status(200).json(response);
    } catch (error) {
        console.error(error); 
        res.status(500).json({ error: "Internal Server Error" });
    }
};



module.exports={addUser,getAllUser,updateSubUser,getSubUserById};


