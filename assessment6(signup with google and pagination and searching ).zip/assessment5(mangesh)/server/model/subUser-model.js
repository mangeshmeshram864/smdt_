import mongoose from "mongoose";
const Schema = mongoose.Schema

const SubUserSchema = new Schema({
    firstName: {
        type: String
    },
    lastName: {
        type: String
    },
    email: {
        type: String
    },
    userId : {type : mongoose.Schema.Types.ObjectId, ref: 'User'}

   

},
    )

const Subusers = mongoose.model("subusers", SubUserSchema)

module.exports=Subusers