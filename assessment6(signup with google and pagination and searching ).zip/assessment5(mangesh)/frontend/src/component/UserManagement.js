import React, { useEffect, useState } from 'react';
import '../styles/userManagement.css';
import { Link, useNavigate } from "react-router-dom";
import axios from 'axios';
import { Box, Button, Pagination, TextField } from '@mui/material';

function  UserCrud() {
    const [users, setUsers] = useState([]);
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [email, setEmail] = useState('');
    const [editUser, setEditUser] = useState(null);
    const [seeUser, setViewUser] = useState(null);
    const [error, setError] = useState("");
    const [searchQuery, setSearchQuery] = useState('');
    const [currentPage, setCurrentPage] = useState(1);
    const [userProfile, setUserProfile] = useState(null);
    const usersPerPage = 5;

    const navigate = useNavigate();
    let token = localStorage.getItem('token');

    // Handle user registration submission
    // const handleSubmit = async (e) => {
    //     e.preventDefault();
    //     const formData = { firstName, lastName, email };

    //     try {
    //         const response = await axios.post('http://localhost:5000/api/add_user', formData, {
    //             headers: {
    //                 Authorization: `${token}`,
    //                 'Content-Type': 'application/json'
    //             }
    //         });
    //         setUsers([...users, response.data]);
    //         setFirstName('');
    //         setLastName('');
    //         setEmail('');
    //         alert("User added");
    //     } catch (err) {
    //         setError('Failed to add user. Please try again.');
    //         console.error(err);
    //     }
    // };

    const viewUserDetails = (user) => {
        setViewUser(user);
    };

    const clearUserToSee = () => {
        setViewUser(null);
    };

    const [data, setData] = useState([]);
    const [pagination, setPagination] = useState({
        total_record: 0,
        per_page: 8,
        current_page: 1,
        total_pages: 1,
    });
    const [loading, setLoading] = useState(false);
    const [searchText, setSearchText] = useState("");

    const fetchSubUser = async (page = 1) => {
        let token = localStorage.getItem('token');
        try {
            setLoading(true);
            const response = await axios.get(`http://localhost:5000/api/getsub_user?page=${page}&searchText=${searchText}`, {
                headers: {
                    Authorization: `${token}`,
                    'Content-Type': 'application/json'
                }
            });
            setData(response.data.subUser);
            setPagination({
                total_record: response.data.pagination.total_record,
                per_page: response.data.pagination.per_page,
                current_page: response.data.pagination.current_page,
                total_pages: response.data.pagination.total_pages,
            });
            setError(null);
        } catch (error) {
            setData([]);
            setError("Failed to fetch data.");
        } finally {
            setLoading(false);
        }
    };

    const fetchUserProfile = async (userId) => {
        let token = localStorage.getItem('token');
        try {
            const response = await axios.get(`http://localhost:5000/api/get_user/${userId}`, {
                headers: {
                    Authorization: `${token}`,
                },
            });
            setUserProfile(response.data); // Assuming response.data contains the user details
        } catch (error) {
            console.error("Failed to fetch user profile:", error);
        }
    };



    useEffect(() => {
        const userId = localStorage.getItem('userId'); // Get userId from local storage
        if (userId) {
            fetchUserProfile(userId); // Fetch user details
        }

        fetchSubUser(pagination.current_page);
    }, [pagination.current_page, searchText]);

    const handleLogout = () => {
        localStorage.removeItem('user');
        navigate('/login');
    };

    const handlePageChange = (event, value) => {
        setPagination((prevPagination) => ({
            ...prevPagination,
            current_page: value,
        }));
    };

    const user = localStorage.getItem('userId')

    console.log('user-----', user)

    const [formData, setFormData] = useState([])

    console.log('data------', formData)


    const fetchUserById = async (user) => {
        try {
            const response = await axios.get(`http://localhost:5000/api/get_user/${user}`,
                {
                    headers: {
                        Authorization: `${token}`,
                        'Content-Type': 'application/json'
                    }
                }


            );
            
            console.log(response)
            setFormData(response.data)
        } catch (error) {
            setFormData([])
        }
    }

    useEffect(() => {
        fetchUserById(user)
    }, [user])

    return (
        <div className="user-management">

            <Link to={'/userProfile'}>
                <Button
                    variant="contained"
                    color="primary"
                    sx={{ ml: 2 }}
                    
                >
                    My Profile
                </Button>
            </Link>
            <h1>Dashboard</h1>
            {userProfile && (
                <div className="user-profile">
                    <h3>Welcome {formData.fname}</h3>
                    {userProfile.profileImage && (
                        <img
                            src={userProfile.profileImage}
                            alt="Profile"
                            className="profile-image"
                            style={{ width: '50px', height: '50px', borderRadius: '50%' }}
                        />
                    )}
                </div>
            )}

            <div className="logout"><button onClick={handleLogout}>Logout</button></div>
            {/* // <form onSubmit={handleSubmit}>
                <div className="add-user">
                    <input
                        type="text"
                        value={firstName}
                        onChange={(e) => setFirstName(e.target.value)}
                        placeholder="First Name"
                        required
                    />
                    <input
                        type="text"
                        value={lastName}
                        onChange={(e) => setLastName(e.target.value)}
                        placeholder="Last Name"
                        required
                    />
                    <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="Email"
                        required
                    />
                    <button type='submit'>Add User</button>
                </div>
            </form> 

            {error && <p className="error">{error}</p>}

            {/* Search Input */}
            <div className="Searchf">
                <Box sx={{ display: "flex", justifyContent: "left", mb: 2 }}>
                    <TextField
                        label="Search"
                        variant="standard"
                        value={searchText}
                        onChange={(e) => setSearchText(e.target.value)}
                    />
                </Box>
            </div>
            <Link to={'/addSubUser'}>
                <Button
                    variant="contained"
                    color="primary"
                    sx={{ ml: 2 }}
                    
                >
                   Add Subuser
                </Button>
            </Link>

            {/* List Users */}
            <table className="user-table">
                <thead>
                    <tr>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {data.map(user => (
                        <tr key={user.id}> {/* Ensure user.id is unique */}
                            <td>{user.firstName}</td>
                            <td>{user.lastName}</td>
                            <td>{user.email}</td>
                            <td>
                            <Link to={`/details/${user._id}`}>
                                <button >View</button>
                            </Link>
                            </td>
                        </tr>
                    ))}
                </tbody>

            </table>

            {/* Pagination */}
            <Box sx={{ display: "flex", justifyContent: "center", mt: 2 }}>
                <Pagination
                    count={pagination.total_pages}
                    page={pagination.current_page}
                    onChange={handlePageChange}
                    color="primary"
                />
            </Box>

      
        </div>
    );
}

export default UserCrud;
