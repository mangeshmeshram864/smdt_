import React, { useEffect, useState } from 'react';
import '../styles/userManagement.css';
import { Link, useNavigate } from "react-router-dom";
import axios from 'axios';
import { Box, Button, Pagination, TextField, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography, CircularProgress, Snackbar } from '@mui/material';

function UserCrud() {
    const [formData, setFormData] = useState([]);
    const [error, setError] = useState("");
    const [searchText, setSearchText] = useState('');
    const [currentPage, setCurrentPage] = useState(1);
    const [userProfile, setUserProfile] = useState(null);
    const [loading, setLoading] = useState(false);
    const [pagination, setPagination] = useState({
        total_record: 0,
        per_page: 5,
        current_page: 1,
        total_pages: 0,
    });
    const [data, setData] = useState([]);
    const navigate = useNavigate();

    const fetchSubUser = async (page = 1) => {
        let token = localStorage.getItem('token');
        try {
            setLoading(true);
            const response = await axios.get(`http://localhost:5000/api/getsub_user?page=${page}&searchText=${searchText}`, {
                headers: {
                    Authorization: `${token}`,
                    'Content-Type': 'application/json'
                }
            });
            setData(response.data.subUser);
            setPagination(response.data.pagination);
            setError(null);
        } catch (error) {
            setData([]);
            setError("Failed to fetch data.");
        } finally {
            setLoading(false);
        }
    };

    const handleLogout = () => {
        localStorage.removeItem('user');
        navigate('/login');
    };

    const handlePageChange = (event, value) => {
        setCurrentPage(value);
        fetchSubUser(value);
    };

    useEffect(() => {
        fetchSubUser(currentPage);
    }, [currentPage, searchText]);

    return (
        <div className="user-management">
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
                <Link to={'/userProfile'}>
                    <Button variant="contained" color="primary">My Profile</Button>
                </Link>
                <Button variant="outlined" color="secondary" onClick={handleLogout}>Logout</Button>
            </Box>

            <Typography variant="h4" gutterBottom>Dashboard</Typography>

            {userProfile && (
                <div className="user-profile">
                    <Typography variant="h6">Welcome {userProfile.fname}</Typography>
                    {userProfile.profileImage && (
                        <img
                            src={userProfile.profileImage}
                            alt="Profile"
                            className="profile-image"
                            style={{ width: '50px', height: '50px', borderRadius: '50%' }}
                        />
                    )}
                </div>
            )}

            <Box sx={{ mb: 2 }}>
                <TextField
                    label="Search"
                    variant="outlined"
                    value={searchText}
                    onChange={(e) => setSearchText(e.target.value)}
                    fullWidth
                />
            </Box>

            {loading ? (
                <CircularProgress />
            ) : (
                <TableContainer>
                    <Table>
                        <TableHead>
                            <TableRow>
                                <TableCell>First Name</TableCell>
                                <TableCell>Last Name</TableCell>
                                <TableCell>Email</TableCell>
                                <TableCell>Actions</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {data.map(user => (
                                <TableRow key={user.id}>
                                    <TableCell>{user.firstName}</TableCell>
                                    <TableCell>{user.lastName}</TableCell>
                                    <TableCell>{user.email}</TableCell>
                                    <TableCell>
                                        <Button variant="outlined" onClick={() => viewUserDetails(user)}>View</Button>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </TableContainer>
            )}

            {error && <Snackbar open={Boolean(error)} message={error} onClose={() => setError('')} />}

            <Box sx={{ display: "flex", justifyContent: "center", mt: 2 }}>
                <Pagination
                    count={pagination.total_pages}
                    page={currentPage}
                    onChange={handlePageChange}
                    color="primary"
                />
            </Box>

            {/* Additional components for Edit and View User Details can be added here */}
        </div>
    );
}

export default UserCrud;
