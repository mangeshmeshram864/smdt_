import axios from "axios";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function AddSubUser() {


    const navigate = useNavigate();
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [email, setEmail] = useState('');
    const [error, setError] = useState("");
    let token = localStorage.getItem('token');
    const [users, setUsers] = useState([]);


    //Handle user registration submission
    const handleSubmit = async (e) => {
        e.preventDefault();
        const formData = { firstName, lastName, email };

        try {
            const response = await axios.post('http://localhost:5000/api/add_user', formData, {
                headers: {
                    Authorization: `${token}`,
                    'Content-Type': 'application/json'
                }
            });
            setUsers([...users, response.data]);
            setFirstName('');
            setLastName('');
            setEmail('');
            alert("User added");
            navigate('/users');
        } catch (err) {
            setError('Failed to add user. Please try again.');
            console.error(err);
        }
}    ;


    return (
   <>
        <form onSubmit={handleSubmit}>

            <div className="add-user">
                <input
                    type="text"
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    placeholder="First Name"
                    required
                />
                <input
                    type="text"
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    placeholder="Last Name"
                    required
                />
                <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Email"
                    required
                />
                <button type='submit'>Add User</button>
            </div>
        </form>

        </>


    )
};


// module.exports = {AddSubUser};