import React from 'react';

// Define a functional component using a const declaration
const MyConstComponent = () => {
    return (
        <div>
            <h1>Component</h1>
        </div>
    );
};

export default MyConstComponent;
