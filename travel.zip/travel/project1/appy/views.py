import datetime 
import random
import uuid
from django.conf import settings
from django.shortcuts import render,redirect
from django.views import View
from .models import User
from django.contrib.auth import authenticate, login, logout
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required, permission_required
from django.contrib import messages
from appy.models import ResetUuid
from django.core.mail import send_mail




# Create your views here.
class Index(View):
    @method_decorator(login_required)
    def get(self,request):
        return render(request,'index.html')
    
class Login(View):
    def get(self, request):
        return render(request, 'login.html')
    
    def post(self, request):
        email = request.POST.get('email')
        password = request.POST.get('password')

        if User.objects.filter(email=email).exists():
            user = authenticate(email=email, password=password)
            if user != None:
                login(request, user)
                return redirect('index')
            else:
                print('Invalid credentials')
        else:
            print('username not found')

        return render(request, 'index.html')
    
class Register(View):
    def get(self, request):
        return render(request, 'register.html')
    def post(self, request):
        firstname = request.POST.get('firstname')
        lastname = request.POST.get('lastname')
        email = request.POST.get('email')
        username = request.POST.get('username')
        password = request.POST.get('password')

        print('inside register')


        if User.objects.filter(email = email).exists():
            print('Email Taken')
            messages.error(request, 'Email taken')

        elif User.objects.filter(username = username).exists():
            print('Username Taken')
            messages.error(request, 'Username taken')

        else:
            User.objects.create_user(
                first_name = firstname,
                last_name = lastname,
                email = email,
                username = username,
                password = password
            )
            print('Registration successfull please login')
            messages.success(request, 'Registration succesfull please login')
            return redirect('login')
        
        return render(request, 'register.html')
    
class LogoutView(View):
    def get(self, request):
        logout(request)
        return redirect('/')
    
class Forgot(View):
    def get(self,request):
        return render(request, 'forgot.html')
    
    def post(self,request):
        email = request.POST.get('email')
        if User.objects.filter(email=email).exists():
            user = User.objects.get(email=email)
            exp_date = datetime.datetime.now() + datetime.timedelta(hours=2)
            uuid_data = uuid.uuid1(random.randint(0, 281474976710655))

            forgot = ResetUuid.objects.create(UUID=uuid_data,user=user,expiry=exp_date)

            url = f"{settings.SITE_URL}/reset/{forgot.UUID}"
            if email:
                subject = 'Password Reset Request'
                message = (
                    "To reset password click the link below to get started\n"
                    f"Rest your password\n\t{url}"
                )

                try:
                    send_mail(subject, message, settings.EMAIL_HOST_USER,[email])
                    print(
                        f"\nSubject = [subject]\message = {message}\nHOST = {settings.EMAIL_HOST_USER}\nmail = {email}"
                    )

                    return redirect("/")
                except Exception as e:
                    return render(request, "forgot.html")
            
            else:
                return render(request, "forgot.html")
        
        else:
            print(f"Invalid Email Address {email}")
        return render(request, "forgot.html")
    

from pytz import timezone
class Reset(View):
    def get(self, request, uuid):
        context = {'uuid':uuid}
        return render(request, 'resetPassword.html',context)
        
    def post(self, request, uuid):
        new_password = request.POST.get('new_password')
        cnfpassword = request.POST.get('confirm_password')
        current_date_time = datetime.datetime.now()

        obj = ResetUuid.objects.get(UUID = uuid)
        user = obj.user
        current_time = current_date_time.astimezone(timezone('UTC'))

        if current_time < obj.expiry and new_password==cnfpassword:
            user.set_password(new_password)
            user.save()
            return redirect('/')
        else:
            print("Link expired")
            return redirect('/')