from django.urls import path
from . import views

urlpatterns = [
    path('',views.Login.as_view(),name='login'),
    path('logout/',views.LogoutView.as_view(),name='logout'),
    path('register/',views.Register.as_view(),name='register'),
    path('index/',views.Index.as_view(),name='index'),
    path('forgot/',views.Forgot.as_view(),name='forgot'),
    path('resetPassword/<uuid>',views.Reset.as_view(),name='resetPassword')
]