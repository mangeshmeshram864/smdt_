const express = require('express');
const router = express.Router();
const { createProduct, fetchAllProducts, fetchProductById, updateProduct } = require('../controller/product');

// /products is already added in base path
router.post('/',createProduct);
router.get('/',fetchAllProducts);
router.get('/:id',fetchProductById);
router.patch('/:id', updateProduct); 

// const productController = require('../controller/Product')
// router.post('/',productController.createProduct)

exports.router = router;