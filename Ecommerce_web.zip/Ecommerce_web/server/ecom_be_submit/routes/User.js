const express = require('express');
const router = express.Router();
const { fetchUserById, updateUser } = require('../controller/User-controller');

// users is already added in base path

router.get('/:id',fetchUserById);
router.patch('/:id', updateUser); 

exports.router = router;