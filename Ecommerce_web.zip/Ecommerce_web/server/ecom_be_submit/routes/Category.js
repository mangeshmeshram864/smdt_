const express = require('express');
const { fetchCategories, createCategory } = require('../controller/Category-Controller');
const router = express.Router();

//brands is already added in the base path
router.get('/', fetchCategories);
router.post('/', createCategory);

exports.router = router;