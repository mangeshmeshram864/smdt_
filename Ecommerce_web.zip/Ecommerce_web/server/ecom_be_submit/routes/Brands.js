const express = require('express');
const { fetchBrands, createBrand } = require('../controller/Brand-Controller');
const router = express.Router();

//brands is already added in the base path
router.get('/', fetchBrands);
router.post('/',createBrand);

exports.router = router;