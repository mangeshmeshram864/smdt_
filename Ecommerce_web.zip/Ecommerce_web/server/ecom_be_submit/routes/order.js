const express = require('express');
const router = express.Router();
const { addToCart, fetchCartByUser, updateCart, deleteFromCart } = require('../controller/Cart-controller');
const { createOrder, fetchOrderByUser, deleteOrder, updateOrder, fetchAllOrders } = require('../controller/Order-controller');

// /orders is already added in base path
router.post('/',createOrder);
router.get('/user/:userId',fetchOrderByUser);
router.delete('/:id', deleteOrder)
router.patch('/:id', updateOrder)
router.get('/',fetchAllOrders)


exports.router = router;