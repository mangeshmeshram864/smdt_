const mongoose = require('mongoose');
const {Schema} = mongoose;

const orderSchema = new Schema({                  
    items:{type:[Schema.Types.Mixed],required:true},
    totalAmount: {type:Number},
    totalItems: {type:Number},
    user: {type: Schema.Types.ObjectId, ref: 'User', required: true},
    //TODO: we can add enum types
    paymentMethod: {type: String, required: true},
    status: {type: String, default: 'pending'},
    selectedAddress: {type:Schema.Types.Mixed,required:true}
})

//the bellow code is for to convert _id into id 

const virtual = orderSchema.virtual('id');        //virtual helps in they create virtual data field
virtual.get(function(){         //jaise ab hum yaha productSchema me virtual id bana rhe hai //aur abhi isme getter, setter function hote hai
    return this._id;            //yaha .get ke callback function me bataya ke apko _id ko he as a id return krna hai coz we are using only id in frontend instead of _id 
})
orderSchema.set('toJSON',{   //and is .set se he virtual enable hote hai and jab bhi hum res.json send karenge to automatically virtual id create hoke add ho jaege hamare data ke response me
    virtuals: true,
    versionKey: false,
    transform: function(doc, ret) {delete ret._id}
})

exports.Order = mongoose.model('Order',orderSchema);