const mongoose = require('mongoose');
const {Schema} = mongoose;

const userSchema = new Schema({                  
    email: {type: String, required: true, unique: true},        
    password: {type: String, required: true},
    role: {type: String, required: true, default:'user'},
    addresses: { type: [Schema.Types.Mixed] },
    //TODO: WE can make a seperate Schema for this
    name :{type: String},
    orders: { type: [Schema.Types.Mixed] },
});

//the bellow code is for to convert _id into id 

const virtual = userSchema.virtual('id');        //virtual helps in they create virtual data field
virtual.get(function(){         //jaise ab hum yaha productSchema me virtual id bana rhe hai //aur abhi isme getter, setter function hote hai
    return this._id;            //yaha .get ke callback function me bataya ke apko _id ko he as a id return krna hai coz we are using only id in frontend instead of _id 
})
userSchema.set('toJSON',{   //and is .set se he virtual enable hote hai and jab bhi hum res.json send karenge to automatically virtual id create hoke add ho jaege hamare data ke response me
    virtuals: true,
    versionKey: false,
    transform: function(doc, ret) {delete ret._id}
});

exports.User = mongoose.model('User',userSchema);