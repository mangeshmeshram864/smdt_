// export function fetchLoggedInUserOrders(userId) {
//   return new Promise(async (resolve) =>{
//      //const response = await fetch('http://localhost:8081/orders/?user.id='+userId) //when we work on backend we will use this api
//     const response = await fetch('http://localhost:8081/orders')     //this is temprary //this is featching all orders but in above api it will fetch only specific user orders 
//     console.log('---------------',response, '--------------')
//     const data = await response.json()
//     resolve({data})
//   }
//   );
// }

// export function fetchLoggedInUser(userId) {
//   return new Promise(async (resolve) =>{
//     const response = await fetch('http://localhost:8081/users/'+userId)     
//     console.log('---------------',response, '--------------')
//     const data = await response.json()
//     resolve({data})
//   }
//   );
// }

// export function updateUser(update) {
//   return new Promise(async (resolve) =>{
//     const response = await fetch('http://localhost:8081/users/'+update.id, {     //update.id isme user ki id hogi jisse hme pata lagega ki konsa update krna hai
//       method : 'PATCH',
//       body: JSON.stringify(update),   //then stringify me hmne update ka data likh diya 
//       headers: {'content-type':'application/json'}
//     }) 
//     const data = await response.json()
//     //TODO : on server it will only return some info of user (not Password)
//     resolve({data})
//   }
//   );
// }











// export function fetchLoggedInUserOrders(userId) {
//   return new Promise(async (resolve) =>{
//     const response = await fetch('http://localhost:8081/orders/?user.id='+userId) 
//     console.log('-----api response-------',response)
//     const data = await response.json()
//     resolve({data})
//   }
//   );
// }

export function fetchLoggedInUserOrders(userId) {
  return new Promise(async (resolve) =>{
    const response = await fetch('http://localhost:8081/orders/user/'+userId) 
    console.log('-----api response-------',response)
    const data = await response.json()
    resolve({data})
  }
  );
};



export function fetchLoggedInUser(userId) {
  return new Promise(async (resolve) =>{
    const response = await fetch('http://localhost:8081/users/'+userId) 
    console.log('-----------------',response)
    const data = await response.json()
    resolve({data})
  }
  );
}

export function updateUser(update) {
  return new Promise(async (resolve) => {
    const response = await fetch('http://localhost:8081/users/'+update.id, {  
      method: 'PATCH',
      body: JSON.stringify(update),
      headers: { 'content-type': 'application/json' },
    });
    const data = await response.json();
    // TODO: on server it will only return some info of user (not password)
    resolve({ data });
  });
}









