
export function fetchProductById(id) {
  return new Promise(async (resolve) =>{
    //TODO: we will not hard-code server URL here
    const response = await fetch('http://localhost:8081/products/'+id)
    const data = await response.json()
    resolve({data})
  }
  );
}

export function createProduct(product) {
  return new Promise(async (resolve) =>{
    const response = await fetch('http://localhost:8081/products/',{
      method : 'POST',
      body: JSON.stringify(product),
      headers: {'content-type':'application/json'}
    });
    const data = await response.json()
    resolve({data})
  }
  );
}

export function updateProduct(update) {
  return new Promise(async (resolve) =>{
    const response = await fetch('http://localhost:8081/products/'+update.id, {
      method : 'PATCH',
      body: JSON.stringify(update),
      headers: {'content-type':'application/json'}
    }) 
    const data = await response.json()
    //TODO : on server it will only return some info of user (not Password)
    resolve({data})
  }
  );
}

export function fetchProductsByFilters(filter,sort,pagination, admin) {
  // filter = {"category":"smartphone", "laptops"}
  //sort = {_sort : "price",_order = "desc"}
  //pagination = {_page:1,_limit=10}
  // TODO : on server we will support multi values in filter
  //TODO: Server will filter the deleted product in case of non-admin

  let queryString = '';
  for(let key in filter){
    const categeoryValues = filter[key];           //this is containing 22 nd line i.e filter array
    if(categeoryValues.length>0) {
      const lastCategoryValue = categeoryValues[categeoryValues.length-1]       //from this we are extracting last value from filter array
      queryString += `${key}=${lastCategoryValue}&`         //http://localhost:8080/products?category=laptops    //and here we Push that last value in queryString
    }
  }
  for(let key in sort) {
    queryString += `${key}=${sort[key]}&`
  }
  // for (let key in sort) {
  //   queryString += `${key} = ${sort[key]}&`;       //here their is a space after both side of equal thats why before sorting was not working i think the is it is querystring when api trying to send sorting values to backend it is also sending spaces thats why it is not working |hahahah
  // }
  console.log(pagination)
  for(let key in pagination){
    queryString += `${key}=${pagination[key]}&`
  }
  if(admin){
    queryString += `admin=true`
  }

  return new Promise(async (resolve) =>{
    //TODO: we will not hard-code server URL here
    const response = await fetch('http://localhost:8081/products?'+queryString) ;
    const data = await response.json();
    const totalItems = await response.headers.get('X-Total-Count')    //X-Total-Count is a feature of json-server
    console.log(totalItems)
    resolve({data:{products:data,totalItems:+totalItems}})
  }
  );

  // return new Promise(async (resolve) => {
  //   //TODO: we will not hard-code server URL here
  //   const response = await fetch('http://localhost:8080/products?' + queryString);
  //   const data = await response.json();
  //   let totalItems = NaN; // Default value in case X-Total-Count is not present
  //   if (response.headers.has('X-Total-Count')) {
  //     totalItems = +response.headers.get('X-Total-Count');
  //   }
  //   console.log(totalItems);
  //   resolve({ data: { products: data, totalItems: totalItems } });
  // });
  
}

export function fetchCategories() {
  return new Promise(async (resolve) =>{
    const response = await fetch('http://localhost:8081/categories') 
    const data = await response.json()
    resolve({data})
  }
  );
}

export function fetchBrands() {
  return new Promise(async (resolve) =>{
    const response = await fetch('http://localhost:8081/brands') 
    const data = await response.json()
    resolve({data})
  }
  );
}
