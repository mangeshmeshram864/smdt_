import NavBar from "../features/navbar/Navbar";
import AdminProductDetail from "../features/counter/product-list/components/AdminProductDetail";

function AdminProductDetailPage() {
    return ( 
        <div>
            <NavBar>
                <AdminProductDetail></AdminProductDetail>
            </NavBar>
            
        </div>
     );
}

export default AdminProductDetailPage;