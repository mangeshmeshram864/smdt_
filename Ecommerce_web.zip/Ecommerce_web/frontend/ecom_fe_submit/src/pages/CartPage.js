import Cart from "../features/cart/cart"

function CartPage () {
    return(
        <div>
            <Cart></Cart>
        </div>
    )
};

export default CartPage;