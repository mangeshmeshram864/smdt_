from django.urls import path
from .views import *

urlpatterns = [
    path('',medicare.as_view(),name='index'),
]
