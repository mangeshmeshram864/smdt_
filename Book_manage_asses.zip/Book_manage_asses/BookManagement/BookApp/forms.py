from django import forms
from .models import Book


class BookForm(forms.ModelForm):
    class Meta:
        model = Book
        fields = "__all__"
        exclude = ('created_at','updated_at')     
        labels = {
            'title': "Title", 
            'author': "Author", 
            'isbn': "isbn", 
            'published_date': "Published Date ",
            'price': "Price",
            'genre': "Genre",
            'language': "language",
            'page_count': "page_count",
            'publisher': "publisher",
            'created_at': "created_at",
            'updated_at': "updated_at",
            'is_bestseller': "is_bestseller",
            'stock_quantity': "stock_quantity",
        }
        widgets = {
            'title': forms.TextInput(attrs={"class": "form-control"}),
            'author': forms.TextInput(attrs={"class": "form-control"}),
            'published_date': forms.DateInput(attrs={"class": "form-control",'type':'date'}),
            'isbn': forms.NumberInput(attrs={"class": "form-control"}),
            'price': forms.NumberInput(attrs={"class": "form-control"}),
            'genre': forms.TextInput(attrs={"class": "form-control"}),
            'language': forms.TextInput(attrs={"class": "form-control"}),  
            'page_count': forms.NumberInput(attrs={"class": "form-control"}),  
            'publisher': forms.TextInput(attrs={"class": "form-control"}),  
            'created_at': forms.DateInput(attrs={"class": "form-control"}),  
            'updated_at': forms.DateInput(attrs={"class": "form-control"}),  
            'is_bestseller': forms.CheckboxInput(attrs={"class": "form-check-input"}),  
            'stock_quantity': forms.TextInput(attrs={"class": "form-control"}),  
        }
