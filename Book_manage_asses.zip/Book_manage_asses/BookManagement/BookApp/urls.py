from django.urls import path
from .views import *

urlpatterns = [
    path('',Create.as_view(),name="create"),
    path('list/',List.as_view(),name="list"),
    path('update/<int:id>',Book_Update.as_view(),name="update"),
    path('delete/<int:id>',Book_Delete.as_view(),name="delete"),

]